export const API = {
  'microdatabaseBaseUrl': 'http://10.110.228.226:5000',
  // 'microdatabaseBaseUrl': 'http://10.110.228.226:5000'
}